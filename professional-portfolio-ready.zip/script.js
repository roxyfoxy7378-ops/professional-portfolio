const defaults = [
  {site:"startup.ai", bid:100},
  {site:"rival.io", bid:2},
  {site:"mywebsite.com", bid:1}
];

let board = JSON.parse(localStorage.getItem("claimrank-board") || "null") || defaults;

function money(n){ return "$" + Number(n).toLocaleString("en-US"); }

function render(){
  board.sort((a,b)=>b.bid-a.bid);
  const el=document.getElementById("board");
  el.innerHTML=board.map((x,i)=>`
    <div class="row ${i===0?"top":""}">
      <div class="rank">#${i+1}</div>
      <div class="site">${escapeHtml(x.site)}<small>public claim</small></div>
      <div class="amount">${money(x.bid)}</div>
    </div>`).join("");
  const total=board.reduce((s,x)=>s+Number(x.bid),0);
  document.getElementById("total").textContent=money(total);
  document.getElementById("heroBids").textContent=money(total);
  document.getElementById("heroClaims").textContent=board.length;
  localStorage.setItem("claimrank-board",JSON.stringify(board));
}
function claimRank(){
  const input=document.getElementById("site");
  const msg=document.getElementById("claimMsg");
  let site=input.value.trim().toLowerCase().replace(/^https?:\/\//,"").replace(/\/.*$/,"");
  if(!site || !site.includes(".")){msg.textContent="Please enter a valid website, e.g. mysite.com";msg.style.color="#c94b36";return}
  const existing=board.find(x=>x.site===site);
  if(existing){
    existing.bid=Math.max(existing.bid+1,2);
    msg.textContent=`You're outbidding ${site} with a demo bid of ${money(existing.bid)}.`;
  }else{
    board.push({site,bid:1});
    msg.textContent=`${site} claimed for a demo $1 bid.`;
  }
  input.value="";
  render();
  document.getElementById("leaderboard").scrollIntoView({behavior:"smooth"});
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
render();
