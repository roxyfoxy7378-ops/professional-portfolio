# ClaimRank

A mobile-friendly demo inspired by the reference video: a public leaderboard where websites can claim a position and climb by bidding more.

## Run
Open `index.html` in a browser.

## Important
This is a frontend demo. The bid button does **not** charge money. For a real business you would add:
- a backend/database
- authentication
- Stripe or another payment provider
- server-side bid validation
- payment/refund rules
- domain verification and fraud protection

## Deploy
Upload `index.html`, `style.css`, `script.js`, and `README.md` to GitHub, then deploy the repository as a static site on your hosting provider.
